let display = document.getElementById('display');
let currentInput = '';
let lastOperator = '';
let needsClear = false;

function appendNumber(num) {
  if (needsClear) {
    currentInput = '';
    needsClear = false;
  }
  currentInput += num;
  updateDisplay();
}

function appendOperator(operator) {
  if (currentInput === '' && operator === '-') {
    currentInput = '-';
    updateDisplay();
    return;
  }
  
  if (currentInput !== '') {
    if (lastOperator !== '') {
      calculate();
    }
    lastOperator = operator;
    currentInput += operator;
    needsClear = false;
  }
  updateDisplay();
}

function appendDecimal() {
  if (needsClear) {
    currentInput = '0';
    needsClear = false;
  }
  
  const lastNumber = currentInput.split(/[-+*/%]/).pop();
  if (!lastNumber.includes('.')) {
    currentInput += currentInput === '' ? '0.' : '.';
    updateDisplay();
  }
}

function clearDisplay() {
  currentInput = '';
  lastOperator = '';
  needsClear = false;
  updateDisplay();
}

function deleteChar() {
  currentInput = currentInput.slice(0, -1);
  updateDisplay();
}

function calculate() {
  if (currentInput === '') return;
  
  try {
    // Replace % operator with % for modulo division
    let expression = currentInput.replace(/%/g, '%');
    
    // Evaluate the expression
    let result = eval(expression);
    
    // Handle division by zero
    if (!isFinite(result)) {
      throw new Error('Division by zero');
    }
    
    // Format the result
    currentInput = Number(result.toFixed(8)).toString();
    lastOperator = '';
    needsClear = true;
    updateDisplay();
  } catch (error) {
    currentInput = 'Error';
    needsClear = true;
    updateDisplay();
  }
}

function updateDisplay() {
  display.value = currentInput || '0';
}

// Add keyboard support
document.addEventListener('keydown', (event) => {
  if (event.key >= '0' && event.key <= '9') {
    appendNumber(event.key);
  } else if (event.key === '.') {
    appendDecimal();
  } else if (['+', '-', '*', '/'].includes(event.key)) {
    appendOperator(event.key);
  } else if (event.key === '%') {
    appendOperator('%');
  } else if (event.key === 'Enter' || event.key === '=') {
    calculate();
  } else if (event.key === 'Backspace') {
    deleteChar();
  } else if (event.key === 'Escape') {
    clearDisplay();
  }
});

// Initial display update
updateDisplay();
